# Football Street 3D
GitHub Pages-ready original 3D street-football prototype.

Files:
- index.html
- README.md

Controls:
- WASD / Arrow keys: move
- F or Freestyle Trick button: perform a trick
- Choose Brazil or Italy

The game uses Three.js from a CDN, so the browser needs internet access.
